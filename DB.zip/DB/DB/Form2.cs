﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DB
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlConnection DB = new MySqlConnection();
            MySqlCommand command = new MySqlCommand("INSERT INTO `users` ( `name`, `login`, `pass`) VALUES (@name, @login, @pass)", db.getConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = Nameuser.Text;
            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = loginuser.Text;
            command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = passworduser.Text;

            db.openConnection();
            if (Nameuser.Text == "" && loginuser.Text == "" && passworduser.Text == "") { MessageBox.Show("Введите данные для регистрации"); return; }
            else if (Nameuser.Text == "" || loginuser.Text == "" || passworduser.Text == "") { MessageBox.Show("Вы ввели не все данные"); return; }
            else if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Здравствуйте," + Nameuser.Text + " Вы успешно зарегистрировались ");
                Hide();
                Form1 form1 = new Form1();
                form1.ShowDialog();
                this.Close();
            }
            else { MessageBox.Show("Вы не смогли зарегистрироваться "); }
            db.closeConnection();
        }
    }
}
